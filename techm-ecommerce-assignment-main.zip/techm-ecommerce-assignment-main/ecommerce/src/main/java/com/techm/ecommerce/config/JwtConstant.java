package com.techm.ecommerce.config;

public class JwtConstant {
    public static final String SECRET_KEY = "vishnutechmsolutiontoecommerce-djdbbdjbsdbbsjjduhfieijsdjcjxjcxcdshijdifjsdfdfnxncbbjj";
    public static final String JWT_HEADER = "Authorization";
}
